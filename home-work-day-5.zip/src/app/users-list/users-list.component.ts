import { Component, OnInit } from "@angular/core";
import { UsersService } from "../users.service";
import { User } from "../shared/users";
import { MatListOption } from "@angular/material/list";

@Component({
  selector: "app-users-list",
  templateUrl: "./users-list.component.html",
  styleUrls: ["./users-list.component.scss"],
})
export class UsersListComponent implements OnInit {
  usersList: User[] = [];
  //tempValue = 0;
  username: string = "";
  name: string = "";
  userType: string = "";
  selectedList: User[] = [];

  constructor(public userService: UsersService) {}

  ngOnInit(): void {
    this.usersList = this.userService.getUSersList();
    //this.tempValue = this.userService.getNumber();
    // setTimeout(()=>{
    //   this.username = "vasylgold";
    //   this.name = "Vasyl"
    // }, 2000)

  }

  search(query: string) {
    this.usersList = this.userService.findUser(query);
  }

  sort(direction: string) {
    console.log(direction);
    this.usersList = this.userService.sortUsers(direction);
  }
  addUser() {
    this.userService.addUser({
      id: Math.floor((Math.random() * 20) +10),
      name: this.name,
      username: this.username,
      email: "",
      role: this.userType,
      phone: "",
      website: ""
    });

    this.usersList =  this.userService.getUSersList();
  }

  selectItem(users: MatListOption[]) {
    this.selectedList = [];
    users.forEach(element => {
      this.selectedList.push(element.value);
    })
  }

  deleteUsers() {
    this.userService.deleteUsers(this.selectedList);
    this.usersList =  this.userService.getUSersList();
  }
}
