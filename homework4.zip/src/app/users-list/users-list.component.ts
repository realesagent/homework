import { Component, OnInit } from "@angular/core";
import { UsersService } from "../users.service";
import { User } from "../shared/users";

@Component({
  selector: "app-users-list",
  templateUrl: "./users-list.component.html",
  styleUrls: ["./users-list.component.scss"],
})
export class UsersListComponent implements OnInit {
  usersList: User[] = [];
  tempValue = 0;

  constructor(public userService: UsersService) {}

  ngOnInit(): void {
    this.usersList = this.userService.getUSersList();
    this.tempValue = this.userService.getNumber();
  }

  foods = [
    { value: "steak-0", viewValue: "Steak" },
    { value: "pizza-1", viewValue: "Pizza" },
    { value: "tacos-2", viewValue: "Tacos" },
  ];
}
